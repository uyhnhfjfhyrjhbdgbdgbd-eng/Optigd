#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/modify/CCParticleSystemQuad.hpp>
using namespace geode::prelude;

static void applySettings() {
    auto director = CCDirector::sharedDirector();
    director->setDisplayStats(Mod::get()->getSettingValue<bool>("show-fps"));
    int64_t fps = Mod::get()->getSettingValue<int64_t>("fps-limit");
    if (fps < 10) fps = 10;
    director->setAnimationInterval(1.0 / static_cast<double>(fps));
}

$on_mod(Loaded) {
    listenForSettingChanges<int64_t>("fps-limit", [](int64_t) { applySettings(); });
    listenForSettingChanges<bool>("show-fps", [](bool) { applySettings(); });
}

class $modify(OptiMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;
        applySettings();
        return true;
    }
};

class $modify(OptiParticles, CCParticleSystemQuad) {
    void draw() {
        if (Mod::get()->getSettingValue<bool>("no-particles")) return;
        CCParticleSystemQuad::draw();
    }
};
